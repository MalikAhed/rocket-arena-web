// Application ABI only. Gameplay algorithms live in pinned, unmodified RocketSim.
#include "vendor/RocketSim/src/RocketSim.h"
#include <emscripten/emscripten.h>
#include <algorithm>
#include <array>
#include <cmath>
#include <cstring>
#include <memory>

using namespace RocketSim;
namespace {
constexpr int MAX_CARS = 8, STRIDE = 51, PAD_OFFSET = 22 + MAX_CARS * STRIDE;
std::unique_ptr<Arena> arena;
std::vector<Car*> cars;
std::vector<BoostPad*> pads;
float state[510]{}, controls[MAX_CARS * 8]{}, configInfo[MAX_CARS][26]{}, padInfo[40 * 4]{};
float hitInfo[MAX_CARS][6]{};
bool unlimited = false, goalLatched = false, ballGround = false;
int goal = 0;
bool goalExplosionEnabled = false, goalBlastApplied = false;
std::array<bool, MAX_CARS> insideGoalAtScore{}, inScoredHalfAtScore{}, goalMouthProtected{};
float goalBlastRemaining=0.f, blastEnd=1.f;
struct Events { unsigned reset=0, jump=0, dodge=0, doubleJump=0, wheel=0, hit=0; float wheelSpeed=0, hitSpeed=0; };
std::array<Events, MAX_CARS> events{};
unsigned worldSerial = 0;
float worldSpeed = 0, worldSurface = 0;
bool previousBallContact = false;
void synchronizeTeleport(btRigidBody& body) {
  // A reset is not a swept movement from the old pose. Bullet otherwise unions
  // the stale interpolation AABB, leaving wheel rays in the old broadphase cell.
  body.setInterpolationWorldTransform(body.getWorldTransform());
  body.setInterpolationLinearVelocity(body.getLinearVelocity());
  body.setInterpolationAngularVelocity(body.getAngularVelocity());
  if(body.getBroadphaseHandle()) arena->_bulletWorld.getBroadphase()->getOverlappingPairCache()->cleanProxyFromPairs(body.getBroadphaseHandle(),arena->_bulletWorld.getDispatcher());
  arena->_bulletWorld.updateSingleAabb(&body);
}
Vec readVec(const float* p) { return Vec(p[0],p[1],p[2]); }
void writeVec(float* p, Vec v) { p[0]=v.x; p[1]=v.y; p[2]=v.z; }
void writePose(float* p, const PhysState& s) {
  writeVec(p,s.pos); writeVec(p+3,s.rotMat.forward); writeVec(p+6,s.rotMat.right);
  writeVec(p+9,s.rotMat.up); writeVec(p+12,s.vel); writeVec(p+15,s.angVel);
}
bool finite(const float* p, int count) { for(int i=0;i<count;i++) if(!std::isfinite(p[i])) return false; return true; }
bool readPose(PhysState& s, const float* p) {
  if (!finite(p,18)) return false;
  Vec f=readVec(p+3), r=readVec(p+6), u=readVec(p+9);
  if(std::abs(f.LengthSq()-1)>0.01 || std::abs(r.LengthSq()-1)>0.01 || std::abs(u.LengthSq()-1)>0.01 || f.Cross(r).Dot(u)<0.99) return false;
  s.pos=readVec(p); s.rotMat=RotMat(f,r,u); s.vel=readVec(p+12); s.angVel=readVec(p+15); return true;
}
void publish() {
  std::fill(std::begin(state),std::end(state),0);
  if(!arena) return;
  state[0]=static_cast<float>(arena->tickCount); state[1]=goal; state[2]=cars.size(); state[3]=pads.size();
  writePose(state+4,arena->ball->GetState());
  for(size_t i=0;i<cars.size();i++) {
    auto s=cars[i]->GetState(); auto& e=events[i]; float* p=state+22+i*STRIDE;
    writePose(p,s); p[18]=s.boost; p[19]=s.isOnGround; p[20]=s.isSupersonic; p[21]=s.isDemoed;
    p[22]=s.HasFlipOrJump(); p[23]=s.isBoosting; p[24]=s.isFlipping; p[25]=e.reset;
    for(int j=0;j<4;j++) { const auto& w=cars[i]->_bulletVehicle.getWheelInfo(j);
      p[26+j*3]=w.m_raycastInfo.m_suspensionLength*BT_TO_UU;
      p[27+j*3]=w.m_steerAngle; p[28+j*3]=w.m_raycastInfo.m_isInContact;
    }
    writeVec(p+38,s.worldContact.hasContact?s.worldContact.contactNormal:Vec(0,0,1));
    p[41]=e.jump; p[42]=e.dodge; p[43]=e.doubleJump; p[44]=e.wheel; p[45]=e.wheelSpeed;
    p[46]=e.hit; p[47]=e.hitSpeed; p[48]=worldSerial; p[49]=worldSpeed; p[50]=worldSurface;
    const auto& hit=s.ballHitInfo; hitInfo[i][0]=hit.isValid;
    hitInfo[i][1]=hit.isValid?static_cast<float>(hit.tickCountWhenHit):-1;
    hitInfo[i][2]=hit.isValid?static_cast<float>(hit.tickCountWhenExtraImpulseApplied):-1;
    writeVec(hitInfo[i]+3,hit.isValid?hit.extraHitVel:Vec());
  }
  for(size_t i=0;i<pads.size();i++) { auto s=pads[i]->GetState(); state[PAD_OFFSET+2*i]=s.isActive; state[PAD_OFFSET+2*i+1]=s.cooldown; }
}
int applyGoalBlast(){
  if(!arena||goalBlastApplied)return 0;
  goalBlastApplied=true;
  const Vec origin=arena->ball->GetState().pos;
  blastEnd=origin.y>=0?1.f:-1.f;goalBlastRemaining=2.f;goalMouthProtected={};
  int launched=0;
  for(size_t i=0;i<cars.size();i++){
    auto car=cars[i];const auto current=car->GetState();
    if(current.isDemoed)continue;
    const float scoredEnd=origin.y>=0?1.f:-1.f;
    const bool affected=goalLatched?inScoredHalfAtScore[i]:current.pos.y*scoredEnd>=0.f;
    if(!affected)continue;
    Vec direction=current.pos-origin;
    const float distance=direction.Length();
    const float falloff=std::pow(std::clamp(1.f-distance/6500.f,0.f,1.f),1.6f);
    const float strength=120.f+3200.f*falloff;
    if(current.isOnGround){
      // Grounded cars slide along their supporting surface; no artificial lift.
      const Vec normal=current.worldContact.hasContact?current.worldContact.contactNormal:Vec(0,0,1);
      direction-=normal*direction.Dot(normal);
    }
    if(direction.LengthSq()<1.f)direction=Vec(0,-scoredEnd,0);
    direction=direction.Normalized();
    Vec velocity=current.vel+direction*strength;
    const bool alreadyInside=goalLatched?insideGoalAtScore[i]:std::abs(current.pos.y)>RLConst::ARENA_EXTENT_Y;
    goalMouthProtected[i]=!alreadyInside;
    const float distanceToGoal=RLConst::ARENA_EXTENT_Y-current.pos.y*scoredEnd;
    if(!alreadyInside&&distanceToGoal<1200.f&&current.vel.y*scoredEnd>0.f){
      // Only an incoming car near the mouth needs the extra escape impulse.
      // Preserve its radial lateral/vertical angle within the normal speed budget.
      const float proximity=std::clamp(1.f-distanceToGoal/1200.f,0.f,1.f);
      const float escapeSpeed=900.f+1300.f*proximity;
      if(-scoredEnd*velocity.y<escapeSpeed)velocity.y=-scoredEnd*escapeSpeed;
      const float otherSpeed=std::sqrt(velocity.x*velocity.x+velocity.z*velocity.z);
      const float budget=std::sqrt(std::max(0.f,2300.f*2300.f-velocity.y*velocity.y));
      if(otherSpeed>budget&&otherSpeed>0.f){velocity.x*=budget/otherSpeed;velocity.z*=budget/otherSpeed;}
    }
    if(velocity.Length()>2300.f)velocity=velocity.Normalized()*2300.f;
    car->_rigidBody.setLinearVelocity(velocity*UU_TO_BT);
    car->_rigidBody.activate(true);launched++;
  }
  return launched;
}
void applyGoalMouthPressure(){
  if(goalBlastRemaining<=0.f)return;
  goalBlastRemaining=std::max(0.f,goalBlastRemaining-1.f/120.f);
  for(size_t i=0;i<cars.size();i++){
    if(!goalMouthProtected[i])continue;
    const auto current=cars[i]->GetState();
    if(current.isDemoed)continue;
    const float gap=RLConst::ARENA_EXTENT_Y-current.pos.y*blastEnd;
    if(gap<0.f||gap>160.f||current.vel.y*blastEnd<=0.f)continue;
    // Residual blast pressure only at the mouth during the live celebration.
    // No position clamp, artificial floor, or forced vertical launch.
    Vec velocity=current.vel;velocity.y=-blastEnd*2200.f;
    const float other=std::sqrt(velocity.x*velocity.x+velocity.z*velocity.z);
    const float budget=std::sqrt(2300.f*2300.f-2200.f*2200.f);
    if(other>budget){velocity.x*=budget/other;velocity.z*=budget/other;}
    cars[i]->_rigidBody.setLinearVelocity(velocity*UU_TO_BT);
  }
}
void clearEvents() { events={}; worldSerial=0; worldSpeed=worldSurface=0; previousBallContact=false; goal=0; goalLatched=false; goalBlastApplied=false; goalBlastRemaining=0.f; ballGround=false; }
int addCar(int team, const CarConfig& config) {
  if(!arena || cars.size()>=MAX_CARS || (team!=0&&team!=1)) return -1;
  const int index=cars.size(); auto car=arena->AddCar(static_cast<Team>(team),config); cars.push_back(car);
  float* p=configInfo[index]; writeVec(p,config.hitboxSize); writeVec(p+3,config.hitboxPosOffset);
  for(int w=0;w<4;w++) { auto pair=w<2?config.frontWheels:config.backWheels; auto v=pair.connectionPointOffset;
    if(w%2) v.y=-v.y; writeVec(p+6+w*5,v); p[9+w*5]=pair.wheelRadius; p[10+w*5]=pair.suspensionRestLength;
  }
  publish(); return index;
}
void observeWorld(Vec incoming) {
  bool contact=false; ballGround=false; float speed=0, surface=0;
  auto dispatcher=arena->_bulletWorld.getDispatcher();
  for(int i=0;i<dispatcher->getNumManifolds();i++) {
    auto m=dispatcher->getManifoldByIndexInternal(i);
    const bool ballA=m->getBody0()==&arena->ball->_rigidBody, ballB=m->getBody1()==&arena->ball->_rigidBody;
    if(!ballA&&!ballB) continue;
    auto other=ballA?m->getBody1():m->getBody0(); if(!other->isStaticObject()) continue;
    for(int j=0;j<m->getNumContacts();j++) { auto& cp=m->getContactPoint(j); if(cp.getDistance()>0.04f) continue;
      Vec normal=cp.m_normalWorldOnB; if(ballB) normal*=-1;
      contact=true; if(normal.z>0.7f) ballGround=true;
      float hitSpeed=std::max(0.f,-incoming.Dot(normal));
      if(hitSpeed>speed) { speed=hitSpeed; surface=normal.z>0.7f?0:normal.z<-.7f?2:1; }
    }
  }
  if(contact&&!previousBallContact&&speed>30) { worldSerial++; worldSpeed=speed; worldSurface=surface; }
  previousBallContact=contact;
}
}

extern "C" {
EMSCRIPTEN_KEEPALIVE int physics_init(const unsigned char* data,const int* sizes,int count) {
  try { if(count<1||count>100) return 0;
    std::map<GameMode,std::vector<FileData>> meshes; size_t offset=0;
    for(int i=0;i<count;i++) { if(sizes[i]<=0||sizes[i]>10000000) return 0; meshes[GameMode::SOCCAR].emplace_back(data+offset,data+offset+sizes[i]); offset+=sizes[i]; }
    RocketSim::InitFromMem(meshes,true); return 1;
  } catch(...) { return 0; }
}
EMSCRIPTEN_KEEPALIVE int physics_createArena() {
  try { arena.reset(); cars.clear(); pads.clear(); clearEvents(); std::fill(std::begin(controls),std::end(controls),0);
    ArenaConfig config; config.noBallRot=false;
    arena.reset(Arena::Create(GameMode::SOCCAR,config,120));
    arena->SetGoalScoreCallback([](Arena*,Team team,void*) { if(!goalLatched) {
      goal=static_cast<int>(team)+1;goalLatched=true;
      const float scoredEnd=arena->ball->GetState().pos.y>=0?1.f:-1.f;
      for(size_t i=0;i<cars.size();i++){
        const float y=cars[i]->GetState().pos.y;
        insideGoalAtScore[i]=std::abs(y)>RLConst::ARENA_EXTENT_Y;
        inScoredHalfAtScore[i]=y*scoredEnd>=0.f;
      }
      if(goalExplosionEnabled)applyGoalBlast();
    } });
    pads=arena->GetBoostPads();
    std::stable_sort(pads.begin(),pads.end(),[](BoostPad* a,BoostPad* b){return a->config.isBig&&!b->config.isBig;});
    if(pads.size()>40) return 0;
    for(size_t i=0;i<pads.size();i++) {writeVec(padInfo+i*4,pads[i]->config.pos);padInfo[i*4+3]=pads[i]->config.isBig;}
    publish(); return 1;
  } catch(...) { return 0; }
}
EMSCRIPTEN_KEEPALIVE int physics_addCar(int team,int preset) { return addCar(team,preset==1?CAR_CONFIG_DOMINUS:CAR_CONFIG_OCTANE); }
EMSCRIPTEN_KEEPALIVE int physics_addConfiguredCar(int team,int negativePointer) {
  if(negativePointer>=0) return physics_addCar(team,negativePointer);
  const float* p=reinterpret_cast<const float*>(-static_cast<intptr_t>(negativePointer));
  if(!finite(p,24)) return -1;
  CarConfig c=CAR_CONFIG_OCTANE; c.hitboxSize=readVec(p); c.hitboxPosOffset=readVec(p+4);
  c.frontWheels.wheelRadius=p[8]; c.frontWheels.suspensionRestLength=p[9]; c.frontWheels.connectionPointOffset=readVec(p+12);
  c.backWheels.wheelRadius=p[16]; c.backWheels.suspensionRestLength=p[17]; c.backWheels.connectionPointOffset=readVec(p+20);
  c.threeWheels=false; c.dodgeDeadzone=.5f;
  if(c.hitboxSize.x<=0||c.hitboxSize.y<=0||c.hitboxSize.z<=0||p[8]<=0||p[9]<=0||p[16]<=0||p[17]<=0) return -1;
  return addCar(team,c);
}
EMSCRIPTEN_KEEPALIVE float* physics_getStatePtr(){return state;}
EMSCRIPTEN_KEEPALIVE int physics_getStateSize(){return 510;}
EMSCRIPTEN_KEEPALIVE float* physics_getControlsPtr(){return controls;}
EMSCRIPTEN_KEEPALIVE float* physics_getPadInfoPtr(){return padInfo;}
EMSCRIPTEN_KEEPALIVE float* physics_getCarConfig(int i){return i>=0&&i<(int)cars.size()?configInfo[i]:nullptr;}
EMSCRIPTEN_KEEPALIVE float* physics_getBallHitInfo(int i){return i>=0&&i<(int)cars.size()?hitInfo[i]:nullptr;}
EMSCRIPTEN_KEEPALIVE float physics_getBallRadius(){return arena?arena->ball->GetRadius():RLConst::BALL_COLLISION_RADIUS_SOCCAR;}
EMSCRIPTEN_KEEPALIVE int physics_getBallOnGround(){return ballGround;}
EMSCRIPTEN_KEEPALIVE void physics_clearGoalFlag(){goal=0;state[1]=0;}
EMSCRIPTEN_KEEPALIVE void physics_setUnlimitedBoost(int enabled){unlimited=enabled!=0;}
EMSCRIPTEN_KEEPALIVE void physics_resetKickoff(int seed){
  if(!arena)return; arena->ResetToRandomKickoff(seed);
  for(auto car:cars)synchronizeTeleport(car->_rigidBody);
  synchronizeTeleport(arena->ball->_rigidBody);
  clearEvents(); std::fill(std::begin(controls),std::end(controls),0); publish();
}
EMSCRIPTEN_KEEPALIVE void physics_step(int ticks){
  if(!arena)return; ticks=std::clamp(ticks,0,12000);
  for(int tick=0;tick<ticks;tick++) {
    std::array<CarState,MAX_CARS> before{}; Vec ballVelocity=arena->ball->GetState().vel;
    for(size_t i=0;i<cars.size();i++) {
      before[i]=cars[i]->GetState(); float* p=controls+i*8;
      auto axis=[&](int j){return std::isfinite(p[j])?std::clamp(p[j],-1.f,1.f):0.f;};
      CarControls c; c.throttle=axis(0);c.steer=axis(1);c.pitch=axis(2);c.yaw=axis(3);c.roll=axis(4);
      c.jump=std::isfinite(p[5])&&p[5]>.5f;c.boost=std::isfinite(p[6])&&p[6]>.5f;c.handbrake=std::isfinite(p[7])&&p[7]>.5f;
      cars[i]->controls=c; if(unlimited) cars[i]->_internalState.boost=100;
    }
    applyGoalMouthPressure();
    arena->Step(1); observeWorld(ballVelocity);
    for(size_t i=0;i<cars.size();i++) {
      if(unlimited)cars[i]->_internalState.boost=100;
      auto after=cars[i]->GetState(); auto& old=before[i]; auto& e=events[i];
      if(after.hasJumped&&!old.hasJumped)e.jump++;
      if(after.hasFlipped&&!old.hasFlipped)e.dodge++;
      if(after.hasDoubleJumped&&!old.hasDoubleJumped)e.doubleJump++;
      if(after.HasFlipReset()&&!old.HasFlipReset())e.reset++;
      if(after.isOnGround&&!old.isOnGround) {e.wheel++;e.wheelSpeed=old.vel.Length();}
      if(after.ballHitInfo.isValid&&(!old.ballHitInfo.isValid||after.ballHitInfo.tickCountWhenHit!=old.ballHitInfo.tickCountWhenHit)) {e.hit++;e.hitSpeed=(old.vel-ballVelocity).Length();}
    }
  }
  publish();
}
EMSCRIPTEN_KEEPALIVE void physics_setGoalExplosionEnabled(int enabled){goalExplosionEnabled=enabled!=0;}
EMSCRIPTEN_KEEPALIVE int physics_goalExplosion(){const int count=applyGoalBlast();publish();return count;}
EMSCRIPTEN_KEEPALIVE int physics_setBallState(const float* p){
  if(!arena)return 0; BallState s; if(!readPose(s,p))return 0;
  arena->ball->SetState(s); synchronizeTeleport(arena->ball->_rigidBody);
  previousBallContact=false;ballGround=false;goal=0;goalLatched=false; goalBlastApplied=false; goalBlastRemaining=0.f;publish();return 1;
}
EMSCRIPTEN_KEEPALIVE int physics_setCarState(int i,const float* p){
  if(!arena||i<0||i>=(int)cars.size()||!finite(p,24))return 0;
  CarState s; if(!readPose(s,p))return 0;
  s.boost=std::clamp(p[18],0.f,100.f);s.isOnGround=p[19]!=0;s.hasJumped=p[20]!=0;s.hasDoubleJumped=p[21]!=0;s.hasFlipped=p[22]!=0;s.airTimeSinceJump=std::max(0.f,p[23]);
  cars[i]->SetState(s);synchronizeTeleport(cars[i]->_rigidBody);
  cars[i]->controls=CarControls();std::fill(controls+i*8,controls+i*8+8,0);events[i]={};publish();return 1;
}
EMSCRIPTEN_KEEPALIVE int physics_controlBall(int i,int action){
  if(!arena||i<0||i>=(int)cars.size()||action<0||action>3)return 0;
  auto car=cars[i]->GetState();BallState ball;
  Vec forward=car.rotMat.forward.To2D().Normalized(); if(forward.LengthSq()<.1f)forward=Vec(0,1,0);
  if(action==0){
    ball.pos=car.pos+forward*200;
    ball.pos.z=std::max(car.pos.z,RLConst::BALL_REST_Z);
    ball.vel=car.vel;
  }
  if(action==1){ball.pos=car.pos+car.rotMat.up*(arena->ball->GetRadius()+40);ball.vel=car.vel;}
  if(action==2){
    // Pass the existing ball toward the moving player, not a new ball spawned
    // along the player's heading (which can point out of the field or net).
    ball=arena->ball->GetState();
    const float flightTime=std::clamp((car.pos-ball.pos).Length()/1200.f,.35f,2.f);
    Vec target=car.pos+car.vel*flightTime;
    target.z=std::max(target.z,RLConst::BALL_REST_Z);
    ball.vel=(target-ball.pos)/flightTime-arena->GetMutatorConfig().gravity*(flightTime*.5f);
    if(ball.vel.Length()>RLConst::BALL_MAX_SPEED)ball.vel=ball.vel.Normalized()*RLConst::BALL_MAX_SPEED;
  }
  if(action==3){
    // Launch is an impulse, not a teleport or replacement of horizontal motion.
    ball=arena->ball->GetState();
    ball.vel+=Vec(0,0,750);
  }
  arena->ball->SetState(ball);synchronizeTeleport(arena->ball->_rigidBody);
  previousBallContact=false;ballGround=false;goal=0;goalLatched=false; goalBlastApplied=false; goalBlastRemaining=0.f;publish();return 1;
}
EMSCRIPTEN_KEEPALIVE void physics_destroy(){arena.reset();cars.clear();pads.clear();publish();}
EMSCRIPTEN_KEEPALIVE int physics_sourceVersion(){return 1;}
}
